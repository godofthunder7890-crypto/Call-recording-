package com.callautoupload;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UploadService extends Service {

    private ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String filePath = intent.getStringExtra("file_path");
        if (filePath == null) return START_NOT_STICKY;

        SharedPreferences prefs = getSharedPreferences("CallUploadPrefs", MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("enabled", false);
        if (!enabled) return START_NOT_STICKY;

        boolean uploadTelegram = prefs.getBoolean("upload_telegram", false);
        boolean uploadDrive    = prefs.getBoolean("upload_drive", false);
        String  token          = prefs.getString("telegram_token", "");
        String  chatId         = prefs.getString("telegram_chat_id", "");

        File file = new File(filePath);
        if (!file.exists()) {
            Log.e("UploadService", "File not found: " + filePath);
            return START_NOT_STICKY;
        }

        // Upload in background
        executor.execute(() -> {
            // Upload to Telegram
            if (uploadTelegram && !token.isEmpty() && !chatId.isEmpty()) {
                Log.d("UploadService", "Uploading to Telegram...");
                TelegramUploader.uploadFile(token, chatId, file, success -> {
                    Log.d("UploadService", "Telegram upload: " + (success ? "SUCCESS" : "FAILED"));
                });
            }

            // Upload to Google Drive
            if (uploadDrive) {
                Log.d("UploadService", "Uploading to Google Drive...");
                DriveUploader.uploadFile(getApplicationContext(), file, success -> {
                    Log.d("UploadService", "Drive upload: " + (success ? "SUCCESS" : "FAILED"));
                });
            }

            stopSelf();
        });

        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
