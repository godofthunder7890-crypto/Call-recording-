# 📞 Call Auto Upload — Android App

Har call recording automatically **Google Drive** + **Telegram Bot** pe upload ho jayegi!

---

## 🚀 GitHub se APK Kaise Banayein (Step by Step)

### Step 1 — GitHub Account
- **github.com** pe jaao aur free account banao

### Step 2 — New Repository Banao
1. Green **"New"** button dabao
2. Repository name: `CallAutoUpload`
3. **Public** select karo
4. **Create repository** dabao

### Step 3 — Files Upload Karo
1. **"uploading an existing file"** link dabao
2. Is ZIP ke andar ke saare files drag & drop karo
3. **Commit changes** dabao

### Step 4 — APK Build Hoga Automatically!
1. **Actions** tab pe jaao
2. **"Build APK"** workflow run hoga automatically
3. 5-10 minute mein APK ready!
4. **Artifacts** section mein **"CallAutoUpload-APK"** download karo

---

## 📱 App Setup (APK Install Karne Ke Baad)

### Telegram Bot Setup:
1. Telegram mein **@BotFather** search karo
2. `/newbot` bhejo → naam daalo → **Token** milega
3. Apne bot ko ek message bhejo
4. Browser mein kholo: `https://api.telegram.org/bot{TOKEN}/getUpdates`
5. Response mein `"chat":{"id":XXXXXXX}` — yeh hai tumhara **Chat ID**

### App Mein Settings:
1. App kholo → **Telegram Bot Token** daalo
2. **Chat ID** daalo
3. **"Test Telegram"** dabao — message aayega ✅
4. **"Sign In with Google"** dabao → Drive connect karo
5. Dono switches ON karo
6. **"Settings Save Karo"** dabao
7. **Master Switch** ON karo — ho gaya! 🎉

---

## ⚠️ Important Notes

- **Android 9+** required
- Call recording India mein legal hai apni khud ki calls ke liye
- Kuch phones (Samsung One UI 4+) mein system call recorder better kaam karta hai
- WhatsApp/Telegram calls record nahi hongi — sirf normal phone calls
- Battery optimization mein app ko **"Unrestricted"** set karo

---

## 📁 Project Structure

```
CallAutoUpload/
├── .github/workflows/build.yml   ← GitHub Actions (APK build)
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/callautoupload/
│   │   ├── MainActivity.java      ← Settings screen
│   │   ├── CallReceiver.java      ← Call detect karta hai
│   │   ├── RecordingService.java  ← Recording karta hai
│   │   ├── UploadService.java     ← Upload manage karta hai
│   │   ├── TelegramUploader.java  ← Telegram pe bhejta hai
│   │   ├── DriveUploader.java     ← Drive pe bhejta hai
│   │   └── DriveSignInActivity.java
│   └── res/
│       ├── layout/activity_main.xml
│       └── values/
└── build.gradle
```
