package com.callautoupload;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import okhttp3.*;

public class TelegramUploader {

    private static final OkHttpClient client = new OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .build();

    public interface UploadCallback {
        void onResult(boolean success);
    }

    public static void uploadFile(String botToken, String chatId, File file, UploadCallback callback) {
        String timestamp = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date());
        String caption = "📞 *Call Recording*\n🕐 " + timestamp + "\n📁 " + file.getName();

        String url = "https://api.telegram.org/bot" + botToken + "/sendDocument";

        RequestBody requestBody = new MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart("caption", caption)
            .addFormDataPart("parse_mode", "Markdown")
            .addFormDataPart("document", file.getName(),
                RequestBody.create(file, MediaType.parse("audio/mpeg")))
            .build();

        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();

        try {
            Response response = client.newCall(request).execute();
            boolean success = response.isSuccessful();
            Log.d("TelegramUploader", "Response: " + response.code() + " " + response.body().string());
            if (callback != null) callback.onResult(success);
        } catch (IOException e) {
            Log.e("TelegramUploader", "Upload failed: " + e.getMessage());
            if (callback != null) callback.onResult(false);
        }
    }

    public static void sendTestMessage(String botToken, String chatId, UploadCallback callback) {
        String url = "https://api.telegram.org/bot" + botToken + "/sendMessage";

        RequestBody body = new FormBody.Builder()
            .add("chat_id", chatId)
            .add("text", "✅ *Call Auto Upload App* connected successfully!\n\nAb teri har call recording automatically yahan aayegi. 🎉")
            .add("parse_mode", "Markdown")
            .build();

        Request request = new Request.Builder().url(url).post(body).build();

        new Thread(() -> {
            try {
                Response response = client.newCall(request).execute();
                if (callback != null) callback.onResult(response.isSuccessful());
            } catch (IOException e) {
                if (callback != null) callback.onResult(false);
            }
        }).start();
    }
}
