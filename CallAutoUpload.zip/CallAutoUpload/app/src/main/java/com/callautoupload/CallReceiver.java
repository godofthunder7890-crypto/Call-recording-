package com.callautoupload;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.TelephonyManager;

public class CallReceiver extends BroadcastReceiver {

    private static boolean isRecording = false;
    private static String callState = "IDLE";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("CallUploadPrefs", Context.MODE_PRIVATE);

        // Check if app is enabled
        if (!prefs.getBoolean("enabled", false)) return;

        String action = intent.getAction();
        String state  = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        if (TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(action)) {

            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                // Phone ringing — incoming call
                callState = "RINGING";

            } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                // Call connected — start recording
                if (!isRecording) {
                    isRecording = true;
                    callState = "ACTIVE";
                    startRecording(context);
                }

            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
                // Call ended
                if (isRecording) {
                    isRecording = false;
                    callState = "IDLE";
                    stopRecordingAndUpload(context);
                }
            }
        }

        // Outgoing call
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(action)) {
            callState = "OUTGOING";
        }
    }

    private void startRecording(Context context) {
        Intent intent = new Intent(context, RecordingService.class);
        intent.setAction("START");
        context.startForegroundService(intent);
    }

    private void stopRecordingAndUpload(Context context) {
        Intent intent = new Intent(context, RecordingService.class);
        intent.setAction("STOP");
        context.startService(intent);
    }
}
